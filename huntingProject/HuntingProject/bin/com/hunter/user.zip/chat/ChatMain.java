package com.hunter.user.chat;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;

import com.hunter.ui.map.TableMap;
import com.hunter.user.UserMain;

public class ChatMain extends JPanel{
   UserMain main;
   JPanel p_west;//���̺���,ä����Ȳ ���� �г�
   JPanel p_west_north;//west�� ���̺��� �г�
   JPanel p_west_center;//west�� ä����Ȳ �г�
   
   JPanel p_center;//
   JPanel p_center_north;
   JPanel p_center_center;
   
   TableMap tableMap;//����� ���̺���
   
   public ChatMain(UserMain main) {
      this.main=main;
      setLayout(new BorderLayout());
      
      //p_westó��
      p_west = new JPanel();
      p_west.setLayout(new BorderLayout(0,0));
      p_west.setPreferredSize(new Dimension(700, 900));

      p_west_north = new JPanel();
      tableMap = new TableMap(this);
      //p_west_north.setLayout(new BorderLayout());
      p_west_north.setPreferredSize(new Dimension(700,450));
      p_west_north.setBackground(Color.GRAY);
      //tableMap = new TableMap();
      p_west_center = new JPanel();
      p_west_center.setPreferredSize(new Dimension(700,450));
      p_west_center.setBackground(Color.PINK);
      
      
      //p_centeró��
      p_center = new JPanel();
      p_center.setLayout(new BorderLayout());
      p_center.setPreferredSize(new Dimension(700, 900));

      p_center_north = new JPanel();
      p_center_north.setPreferredSize(new Dimension(700,450));
      p_center_north.setBackground(Color.ORANGE);
      p_center_center = new JPanel();
      p_center_center.setPreferredSize(new Dimension(700, 450));
      p_center_center.setBackground(Color.BLACK);
      
      //����
      p_west_north.add(tableMap);
      p_west.add(p_west_north,BorderLayout.NORTH);
      p_west.add(p_west_center);
      add(p_west,BorderLayout.WEST);
      
      p_center.add(p_center_north,BorderLayout.NORTH);
      p_center.add(p_center_center);
      add(p_center);
      
      setBackground(Color.RED);
      //setSize(1400,900);
      setPreferredSize(new Dimension(1400, 900));
      setVisible(true);
   }
}