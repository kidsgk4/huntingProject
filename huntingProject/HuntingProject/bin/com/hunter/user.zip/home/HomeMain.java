package com.hunter.user.home;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import com.hunter.user.User;
import com.hunter.user.UserMain;
import com.hunter.user.home.BillMain;
import com.hunter.user.chat.ChatMain;
import com.hunter.user.game.GameMain;
import com.hunter.user.order.OrderMain;

public class HomeMain extends JPanel {
	// ��� Ŭ����
	UserMain userMain;
	User user;
	
	OrderMain orderMain;
	ChatMain chatMain;
	GameMain gameMain;
	BillMain billMain;

	// ȭ����ȯ
	String[] mainTitle = { "orderMain","chatMain", "gameMain", "billMain" };
	JPanel[] pages = new JPanel[mainTitle.length];

	// ������
	JPanel container; // ��ü�� ���δ� ����
	JPanel top_area; // ��� ����
	JLabel la_table, la_user;// ��� ���� ����_���� ���� ����
	JPanel p_order, p_chat, p_game, p_check;
	JLabel la_order, la_chat, la_game, la_check;
	JButton bt_exit;

	public HomeMain(UserMain userMain, User user) {
		this.userMain = userMain;
		this.user = user;

		// �޸𸮿� �ø���
		container = new JPanel();
		// �ʱ�ȭ ȭ�� �޸𸮿� �ø���
		pages[0] = new OrderMain(userMain, user);
		pages[1] = new ChatMain(userMain);
		pages[2] = new GameMain();
		pages[3] = new BillMain(userMain, user);

		// ��ܿ���
		top_area = new JPanel();
		la_table = new JLabel();
		la_user = new JLabel();
		// ��ư����
		p_order = new JPanel();
		p_chat = new JPanel();
		p_game = new JPanel();
		p_check = new JPanel();
		la_order = new JLabel("Order");
		la_chat = new JLabel("Chat");
		la_game = new JLabel("Game");
		la_check = new JLabel("Check");
		bt_exit = new JButton("EXIT");

		// ������ �����ϱ�
		Dimension d = new Dimension(300, 800);
		container.setPreferredSize(new Dimension(1250, 850));
		top_area.setPreferredSize(new Dimension(1250, 100));
		p_order.setPreferredSize(d);
		p_chat.setPreferredSize(d);
		p_game.setPreferredSize(d);
		p_check.setPreferredSize(d);
		container.setBackground(Color.RED);
		top_area.setBackground(Color.GREEN);
		p_order.setBackground(Color.BLUE);
		p_chat.setBackground(Color.GRAY);
		p_game.setBackground(Color.PINK);
		p_check.setBackground(Color.GREEN);

		// ��Ʈ �����ϱ�
		Dimension df = new Dimension(300, 800);
		la_order.setPreferredSize(df);
		la_chat.setPreferredSize(df);
		la_game.setPreferredSize(df);
		la_check.setPreferredSize(df);
		la_order.setHorizontalAlignment(SwingConstants.CENTER);
		la_chat.setHorizontalAlignment(SwingConstants.CENTER);
		la_game.setHorizontalAlignment(SwingConstants.CENTER);
		la_check.setHorizontalAlignment(SwingConstants.CENTER);

		la_table.setFont(new Font("�߰���", Font.BOLD, 50));
		la_table.setForeground(Color.black);
		la_user.setFont(new Font("�߰���", Font.BOLD, 50));
		la_user.setForeground(Color.blue);
		la_order.setFont(new Font("�߰���", Font.BOLD, 50));
		la_chat.setFont(new Font("�߰���", Font.BOLD, 50));
		la_game.setFont(new Font("�߰���", Font.BOLD, 50));
		la_check.setFont(new Font("�߰���", Font.BOLD, 50));
		la_order.setForeground(Color.WHITE);
		la_chat.setForeground(Color.WHITE);
		la_game.setForeground(Color.WHITE);
		la_check.setForeground(Color.WHITE);

		// �����ϱ�
		p_order.add(la_order);
		p_chat.add(la_chat);
		p_game.add(la_game);
		p_check.add(la_check);

		top_area.add(bt_exit);
		top_area.add(la_table);
		top_area.add(la_user);

		// page[]�迭 ����
		container.add(pages[0]);
		container.add(pages[1]);
		container.add(pages[2]);
		container.add(pages[3]);

		container.add(top_area);
		container.add(p_order);
		container.add(p_chat);
		container.add(p_game);
		container.add(p_check);
		add(container);

		// ��ư�� ������ ����
		bt_exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				userMain.showPage(0);
			}
		});
		// ��ư�� ������ ����
		p_order.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				showPage(0);
			}

			public void mouseEntered(MouseEvent e) {
				p_order.setBackground(Color.DARK_GRAY);
			}

			public void mouseExited(MouseEvent e) {
				p_order.setBackground(Color.BLUE);
			}
		});
		p_chat.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				showPage(1);
			}

			public void mouseEntered(MouseEvent e) {
				p_chat.setBackground(Color.DARK_GRAY);
			}

			public void mouseExited(MouseEvent e) {
				p_chat.setBackground(Color.GRAY);
			}
		});
		p_game.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				showPage(2);
			}

			public void mouseEntered(MouseEvent e) {
				p_game.setBackground(Color.DARK_GRAY);
			}

			public void mouseExited(MouseEvent e) {
				p_game.setBackground(Color.PINK);
			}
		});
		p_check.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				getBillMain().getRecords(); //���̺� �ҷ�����
				getBillMain().setUserInfo(); //�������� ����
				getBillMain().tableDesign(); //���̺� ������ ����
				showPage(3);
			}

			public void mouseEntered(MouseEvent e) {
				p_check.setBackground(Color.DARK_GRAY);
			}

			public void mouseExited(MouseEvent e) {
				p_check.setBackground(Color.GREEN);
			}
		});

		pages[0].setVisible(false);// orderMainâ
		pages[1].setVisible(false);// chatMainâ
		pages[2].setVisible(false);// gameMainâ
		pages[3].setVisible(false);// BillMainâ

		setBackground(Color.pink);
		setPreferredSize(new Dimension(1300, 900));
	}

	public void showPage(int page) {
		for (int i = 0; i < pages.length; i++) {
			if (i == page) {
				pages[i].setVisible(true);
			} else {
				pages[i].setVisible(false);
			}
		}
	}

	// �α����� ����� ���̺���ȣ, ���̵� �����ֱ�
	public void setUserInfo() {
		la_table.setText("Table "+Integer.toString(user.getTableNum())+"    ");
		String name="";
		
		if(user.getFlag()) {
			name=user.getMemeber().getId()+" ��";
			la_user.setText(name);
			
		}else {
			name="Guest "+user.getGuest().getGuestId();
			la_user.setText(name);
			
		}
	}
	//billMain ��ȯ�ϴ� �޼���
	public BillMain getBillMain() {
		Object page=pages[3];
		BillMain billMain=(BillMain)page;
		return billMain;
	}
}
