package com.hunter.user.order;

import java.awt.Canvas;
import java.awt.Checkbox;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Product extends JPanel{
	   JPanel page;
	   Canvas can;
	   ImageIcon icon;
	   Image img;
	   JLabel la_name, la_price;
	   Checkbox ch;
	   String path;
	   int product_id;
	   String name;
	   String price;

	   public Product(JPanel page, String path, int product_id, String name, String price) { 
	      this.page = page;
	      this.path = path;
	      this.product_id = product_id;
	      this.name = name;
	      this.price = price;

	      icon = new ImageIcon(path); 
	      img = icon.getImage(); 

	      can = new Canvas() {
	         public void paint(Graphics g) {
	            g.drawImage(img, 0, 0, 146, 80, this);
	         }
	      };
	 
	      can.setPreferredSize(new Dimension(130, 100));
	      la_name = new JLabel(name);
	      la_price = new JLabel(price);
	      ch = new Checkbox();

	      ch.addItemListener(new ItemListener() {
	         public void itemStateChanged(ItemEvent e) {
	            // System.out.println(ch.getState());
	            // System.out.println("checkcheck");
	           /* if (ch.getState()) {
	               list.cartList.add(product_id);
	            } else {
	               list.cartList.remove(product_id);
	            }
	            System.out.println("��ٱ��Ͽ� ����� ��ǰ�� ������ " + list.cartList.size());
	            */
	         }
	      });

	      la_name.setPreferredSize(new Dimension(150, 15)); // ���� �����������ֱ�
	      la_price.setPreferredSize(new Dimension(95, 15)); // ���� �����������ֱ�

	      add(can);
	      add(la_name);
	      add(la_price);
	      add(ch);

	      this.setBackground(Color.WHITE);
	      this.setPreferredSize(new Dimension(225, 200));
	   }
}
