package com.hunter.user.order;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import com.hunter.user.UserMain;

public class SidePage extends JPanel {
	UserMain main;
	String path = "C:/data/";

	JPanel container;
	JPanel p_south; 
	JButton bt_cart; 
	JScrollPane scroll;
	int total;
	// JPanel p_area;
	List cartList = new ArrayList();
	
	public SidePage(UserMain main) {
		/*
		 * p_area = new JPanel(); p_area.setBackground(Color.YELLOW); JScrollPane scroll
		 * = new JScrollPane(p_area); scroll.setPreferredSize(new Dimension(700,740));
		 * add(scroll);
		 */
		this.main = main;
		this.setLayout(new BorderLayout());
	      container = new JPanel();
	      p_south = new JPanel();
	      container.setLayout(new GridLayout(2,3));
	      scroll = new JScrollPane(container);
	      scroll.setPreferredSize(new Dimension(700,700));
	      container.setBackground(Color.BLACK);
	      add(scroll);
	      add(p_south, BorderLayout.SOUTH);
	      bt_cart = new JButton("��ٱ���");
	      p_south.add(bt_cart);
	      
	      selectAll();
	}
	public void selectAll() { 
	      Connection con = main.getCon();
	      PreparedStatement pstmt = null; 
	      ResultSet rs = null;

	      String sql = "select * from menu_list where menu_type_id = 3 order by menu_list_id asc";
	      try {
	         pstmt = con.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
	         rs = pstmt.executeQuery();

	         while (rs.next()) {
	            String filename = path + rs.getString("menu_list_img");
	            int product_id = rs.getInt("menu_list_id");
	            String product_name = rs.getString("menu_list_name");
	            String price = rs.getString("menu_list_price");

	            Product product = new Product(this, filename, product_id, product_name, price);
	            container.add(product);
	         }
	      } catch (SQLException e) {
	         e.printStackTrace();
	      } finally {
	         if (rs != null) {
	            try {
	               rs.close();
	            } catch (SQLException e) {
	               e.printStackTrace();
	            }
	         }
	         if (pstmt != null) {
	            try {
	               pstmt.close();
	            } catch (SQLException e) {
	               e.printStackTrace();
	            }
	         }
	      }
	   }
}
