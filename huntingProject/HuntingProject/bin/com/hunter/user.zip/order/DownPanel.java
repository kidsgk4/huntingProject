package com.hunter.user.order;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;

public class DownPanel extends JPanel{
	public DownPanel() {
		setBackground(Color.BLACK);
		setPreferredSize(new Dimension(1400,100));
	}
}
