package com.hunter.user;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;

import javax.swing.JFrame;
import javax.swing.JPanel;

import com.hunter.db.ConnectionManager;
import com.hunter.user.home.HomeMain;
import com.hunter.user.init.InitMain;
import com.hunter.user.join.JoinMain;
import com.hunter.user.login.LoginMain;
import com.hunter.user.regist.RegistMain;

public class UserMain extends JFrame {
	User user;
	
	InitMain initMain;
	HomeMain homeMain;
	LoginMain loginMain;
	JoinMain joinMain;
	RegistMain registMain;
	

	String[] mainTitle = { "init", "homeMain", "loginMain", "joinMain","registMain" };
	JPanel[] pages = new JPanel[mainTitle.length];
	// ������ ����..
	public JPanel container; 
	
	// DB����
	private Connection con;
	ConnectionManager connectionManager;

	public UserMain() {
		// DB����
		connectionManager = new ConnectionManager();
		con = connectionManager.getConnection();
		
		user=new User();
		// �޸𸮿� �ø���
		container = new JPanel();
		// �ʱ�ȭ ȭ�� �޸𸮿� �ø���
		pages[0] = new InitMain(this,user);
		pages[1] = new HomeMain(this,user);
		pages[2] = new LoginMain(this,user);
		pages[3] = new JoinMain(this,user);
		pages[4] = new RegistMain(this,user);

		// container�� ����
		container.add(pages[0]);
		container.add(pages[1]);
		container.add(pages[2]);
		container.add(pages[3]);
		container.add(pages[4]);
		//container.setBackground(Color.GREEN);
		//container.setBounds(0, 0, 1400, 1000);

		add(container);

		// ������ ������ �����ϱ�!!
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				connectionManager.disconnect(con);
				System.exit(0);
			}
		});

		
		pages[0].setVisible(true);// initâ
		pages[1].setVisible(false);// homeâ
		pages[2].setVisible(false);// Loginâ
		pages[3].setVisible(false);// Joinâ
		pages[4].setVisible(false);// Registâ
		

		setSize(1400, 1000);
		setLocationRelativeTo(null);
		setVisible(true);// â����
	}

	public Connection getCon() {
		return con;
	}
	//Ȩ���� ��ȯ�ϴ� �޼���
	public HomeMain getHomeMain() {
		Object page=pages[1];
		HomeMain homeMain=(HomeMain)page;
		return homeMain;
	}

	public void showPage(int page) {
		for (int i = 0; i < pages.length; i++) {
			if (i == page) {
				pages[i].setVisible(true);
			} else {
				pages[i].setVisible(false);
			}
		}
	}
	public static void main(String[] args) {
		new UserMain();
	}

}
