package com.hunter.user.join;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import com.hunter.user.User;
import com.hunter.user.UserMain;
import com.hunter.util.StringUtil;

public class JoinMain extends JPanel {
	UserMain userMain;
	User user;
	
	JPanel p_north, p_firstRow,p_center, p_south;
	JLabel la_title, la_phone, la_password, la_password2;
	JTextField t_phone;
	JPasswordField t_password;
	JPasswordField t_password2;
	
	JButton bt_check;
	JButton bt_join;
	JButton bt_cancel;
	
	String phone;
	boolean check=false;
	
	public JoinMain(UserMain userMain,User user) {
		this.userMain = userMain;
		this.user=user;
		
		// �޸𸮿� �ø���
		p_north = new JPanel();
		p_firstRow = new JPanel();
		p_center = new JPanel();
		p_south = new JPanel();
		la_title = new JLabel("JOIN");
		la_phone = new JLabel("��ȭ��ȣ");
		la_password = new JLabel("��й�ȣ");
		la_password2 = new JLabel("��й�ȣ Ȯ��");
		t_phone = new JTextField();
		t_password = new JPasswordField();
		t_password2 = new JPasswordField();
		bt_check = new JButton("�ߺ�Ȯ��");
		bt_join = new JButton("����");
		bt_cancel = new JButton("���");

		// ������ �����ϱ�
		this.setBorder(BorderFactory.createEmptyBorder(200, 0, 0, 0));
		la_title.setPreferredSize(new Dimension(150, 100));
		Dimension d = new Dimension(300, 50);
		la_phone.setPreferredSize(new Dimension(300, 50));
		la_password.setPreferredSize(d);
		la_password2.setPreferredSize(d);
		t_phone.setPreferredSize(new Dimension(200, 50));
		t_password.setPreferredSize(d);
		t_password2.setPreferredSize(d);

		bt_check.setPreferredSize(new Dimension(100, 50));
		bt_join.setPreferredSize(new Dimension(100, 30));
		bt_cancel.setPreferredSize(new Dimension(100, 30));

		la_title.setFont(new Font("����", Font.BOLD, 50));
		la_phone.setFont(new Font("����", Font.BOLD, 20));
		la_password.setFont(new Font("����", Font.BOLD, 20));
		la_password2.setFont(new Font("����", Font.BOLD, 20));
		t_phone.setFont(new Font("����", Font.BOLD, 20));
		t_password.setFont(new Font("����", Font.BOLD, 20));
		t_password2.setFont(new Font("����", Font.BOLD, 20));
		
		bt_check.setFont(new Font("����", Font.BOLD, 15));
		bt_join.setFont(new Font("����", Font.BOLD, 20));
		bt_cancel.setFont(new Font("����", Font.BOLD, 20));
		// �����ϱ�
		p_north.add(la_title);
		p_firstRow.add(la_phone);
		p_firstRow.add(t_phone);
		p_firstRow.add(bt_check);
		p_center.add(p_firstRow);
		p_center.add(la_password);
		p_center.add(t_password);
		p_center.add(la_password2);
		p_center.add(t_password2);
		p_south.add(bt_join);
		p_south.add(bt_cancel);

		setLayout(new BorderLayout());
		add(p_north, BorderLayout.NORTH);
		add(p_center);
		add(p_south, BorderLayout.SOUTH);

		//��ư�� ������ ����
		bt_check.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				idCheck();
			}
		});
		bt_join.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				join();
				t_phone.setText("");
				t_password.setText("");
				t_password2.setText("");
			}
		});
		bt_cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				userMain.showPage(0);
				t_phone.setText("");
				t_password.setText("");
				t_password2.setText("");
			}
		});

		//setBackground(Color.YELLOW);
		setPreferredSize(new Dimension(650, 600));
	}
	//���̵��� �ߺ��� üũ�ϴ� �޼���
		public void idCheck() {
			 phone = t_phone.getText();
			Connection con = userMain.getCon();
			PreparedStatement pstmt = null;
			ResultSet rs=null;
			
			String sql = "select * from member_list where member_list_phone=?";
			try {
				pstmt=con.prepareStatement(sql);
				pstmt.setString(1,phone);
				rs=pstmt.executeQuery();
				if(rs.next()) {
					check= false; //�ߺ� ��ȭ��ȣ�� �ִ� ���
					JOptionPane.showMessageDialog(this, "�ߺ��� ���̵� �Դϴ�.");
				}else {
					check= true; //���԰��� ��ȭ��ȣ
					JOptionPane.showMessageDialog(this, "���� ������ ��ȣ �Դϴ�.");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}finally {
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
				if (pstmt != null) {
					try {
						pstmt.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	// ������ ����ϴ� �޼���
	public void join() {
		//�ʱ�ȭ
		
		// ����ڰ� �Է��� �� �޾ƿ���
		String id = StringUtil.getId(phone);
		String pw = new String(t_password.getPassword());
		String pw2 = new String(t_password2.getPassword());
		
		//�ߺ�üũ�� ���� �����ϱ�
		if(check) {
			if (pw.equals(pw2)) {
				JOptionPane.showMessageDialog(this, id + "�� ������ �Ϸ� �Ǿ����ϴ�.");
				save(phone, pw);
				userMain.showPage(0);
				
			} else {
				JOptionPane.showMessageDialog(this, "��й�ȣ�� ����ġ �մϴ�.");
			}
		}else {
			JOptionPane.showMessageDialog(this, "�ߺ� Ȯ���� ������ �ּ���.");
			t_password.setText("");
			t_password2.setText("");
		}
	}
	
	//ȸ�������� ȸ���� ������ db�� �����ϴ� �޼���
	public void save(String phone, String pw) {
		Connection con = userMain.getCon();
		PreparedStatement pstmt = null;

		StringBuffer sb = new StringBuffer();
		sb.append("insert into member_list(member_list_id ,user_type_id, member_list_phone ,member_list_pw,member_list_date)");
		sb.append(" values(seq_member_list.nextval,?,?,?,?)");
		
		int type=user.getMemeber().getType();
		java.util.Date utilDate =new java.util.Date();
		Date date= new Date(utilDate.getTime());
		
		user.getMemeber().setDate(date);
		System.out.println("ȸ�������� ��¥��: "+user.getMemeber().getDate());
		
		try {
			pstmt = con.prepareStatement(sb.toString());
			pstmt.setInt(1,type );//user_type_id
			pstmt.setString(2, phone);//member_list_phone
			pstmt.setString(3, pw );//member_list_pw
			pstmt.setDate(4, date);//member_list_date
			
			pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
