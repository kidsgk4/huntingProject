package com.hunter.admin.money;

import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.SwingConstants;

import com.hunter.admin.Main;

public class MoneyMain extends JPanel {
	Main main;
	MoneyDetail md;

	JPanel p_west, p_east;
	Choice choice;
	JLabel l_date;
	JTable monthTable, dayTable;
	JScrollPane scroll, scroll2;
	MoneyMonthTableModel monthTableModel;
	MoneyDayTableModel dayTableModel;

	int table_no, member_id;
	String date;
	 ArrayList month_list = new ArrayList(); //�޺��� ���� ����Ʈ

	public MoneyMain(Main main) {
		this.main = main;
		// db ����

		setLayout(new BorderLayout(0, 0));
		setPreferredSize(new Dimension(1400, 800));

		p_west = new JPanel();
		add(p_west, BorderLayout.WEST);
		p_west.setPreferredSize(new Dimension(480, 800));
		p_west.setLayout(null);

		choice = new Choice();
		choice.setBounds(115, 40, 300, 20);
		p_west.add(choice);

		p_east = new JPanel();
		add(p_east, BorderLayout.EAST);
		p_east.setPreferredSize(new Dimension(900, 800));
		p_east.setLayout(null);

		l_date = new JLabel("��� ����");
		l_date.setBounds(100, 25, 300, 30);
		l_date.setFont(new Font("MD����ü", Font.PLAIN, 30));
		p_east.add(l_date);

		monthTable = new JTable();
		monthTableModel = new MoneyMonthTableModel();
		monthTable.setRowHeight(65);
		monthTable.setModel(monthTableModel = new MoneyMonthTableModel());
		monthTable.setFont(new Font("MD����ü", Font.PLAIN, 15));
		scroll = new JScrollPane(monthTable);
		scroll.setSize(330, 680);
		scroll.setLocation(100, 80);
		scroll.setPreferredSize(new Dimension(330, 700));
		p_west.add(scroll);

		dayTable = new JTable();
		dayTableModel = new MoneyDayTableModel();
		dayTable.setRowHeight(65);
		dayTable.setModel(dayTableModel = new MoneyDayTableModel());
		dayTable.setFont(new Font("MD����ü", Font.PLAIN, 15));
		scroll2 = new JScrollPane(dayTable);
		scroll2.setLocation(100, 60);
		scroll2.setSize(700, 650);
		scroll2.setPreferredSize(new Dimension(700, 600));
		p_east.add(scroll2);

		choice.add("��� ���");
		//getChoice(); //���߿� �̰� Ǯ����� ���̽� �޾ƿ�����

		JButton bt_detail = new JButton("�� ����");
		bt_detail.setBounds(400, 750, 100, 30);
		bt_detail.setFont(new Font("MD����ü", Font.PLAIN, 15));
		p_east.add(bt_detail);

		JSeparator separator = new JSeparator();
		separator.setForeground(Color.BLACK);
		separator.setBackground(Color.BLACK);
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBounds(20, 20, 1, 770);
		p_east.add(separator);

		bt_detail.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (member_id == 0) {
					JOptionPane.showMessageDialog(main, "Ȯ���� ���̺��� ������ �ּ���!");
					return;
				}
				showDetail();
			}
		});

		monthTable.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				int row = dayTable.getSelectedRow();
				int col = 0;
				date = (String) dayTable.getValueAt(row, col);

				//getDayTable(date);
			}
		});

		dayTable.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				int row = dayTable.getSelectedRow();
				
				//table_no = (Integer) dayTable.getValueAt(row, 1);
				//member_id = (Integer) dayTable.getValueAt(row, 2);
				
				//�ӽ÷� �̰� ���߿� ��������
				member_id=1;
			}
		});
		
		choice.addItemListener(new ItemListener() {
	         public void itemStateChanged(ItemEvent e) {
	            int index = choice.getSelectedIndex();
	            String month=choice.getSelectedItem();
	            Integer obj = (Integer) month_list.get(index);
	            
	            //showAllMonth(obj,month);  //�̰͵� �ϴ� ���߿�...
	         }
	      });

	}
	
	public void getChoice() {
		choice.add("��� ���");
		Connection con = main.getCon();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 1;

		StringBuffer sb = new StringBuffer();
		// sb.append("select member_list_id,
		// member_list_phone,member_list_pw,member_list_date");
		sb.append("select *");
		sb.append(" from member_list order by member_list_id asc");
		// sb.append(" order by member_list_id asc ");

		// System.out.println(sb.toString());
		try {
			pstmt = con.prepareStatement(sb.toString(), ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {	
				choice.add(rs.getString("date")); // ��
				month_list.add(rs.getInt("month_id"));  //���� ���̵� �����;���
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
	}

	public void showDetail() {
		new ShowDetail(this, table_no, member_id);

	}
	

	public void getDayTable(String date) {
		Connection con = main.getCon();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 1;

		StringBuffer sb = new StringBuffer();
		// sb.append("select member_list_id,
		// member_list_phone,member_list_pw,member_list_date");
		sb.append("select *");
		sb.append(" from member_list order by member_list_id asc");
		// sb.append(" order by member_list_id asc ");

		// System.out.println(sb.toString());
		try {
			pstmt = con.prepareStatement(sb.toString(), ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			rs = pstmt.executeQuery();
			rs.last();
			int total = rs.getRow();

			Object[][] data = new Object[total][dayTableModel.columnTitle.length];
			rs.beforeFirst();
			for (int i = 0; i < total; i++) {
				rs.next();
				data[i][0] = count; // ����
				data[i][1] = rs.getInt("member_list_phone"); // ���̺� ��ȣ
				data[i][2] = rs.getString("member_list_pw"); // ������ �ð�
				data[i][3] = rs.getInt("member_list_date"); // �ݾ�
				count++;
			}
			dayTableModel.data = data;
			dayTable.updateUI();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

	public void showAllMonth(int index,String month) {
		Connection con = main.getCon();
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		StringBuffer sb = new StringBuffer();
		// sb.append("select member_list_id,
		// member_list_phone,member_list_pw,member_list_date");
		sb.append("select *");
		sb.append(" from member_list order by member_list_id asc");
		// sb.append(" order by member_list_id asc ");

		// System.out.println(sb.toString());
		try {
			pstmt = con.prepareStatement(sb.toString(), ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			rs = pstmt.executeQuery();
			rs.last();
			int total = rs.getRow();

			Object[][] data = new Object[total][monthTableModel.columnTitle.length];
			rs.beforeFirst();
			for (int i = 0; i < total; i++) {
				rs.next();
				data[i][0] = rs.getString("��¥"); // ��¥
				data[i][1] = rs.getInt("�׳� �Ϸ� �� �����"); // �׳� �Ϸ� �� �����

			}
			monthTableModel.data = data;
			monthTable.updateUI();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/*
	 * public void delete() { Connection con = main.getCon(); PreparedStatement
	 * pstmt = null;
	 * 
	 * String sql = "delete from member_list where member_list_id = " +
	 * member_list_id; System.out.println(sql); try { pstmt =
	 * con.prepareStatement(sql);
	 * 
	 * int result = pstmt.executeUpdate(); if (result == 0) {
	 * JOptionPane.showMessageDialog(this, "���� ����!");
	 * System.out.println(member_list_id); } else {
	 * JOptionPane.showMessageDialog(this, "���� ����!"); } } catch (SQLException e) {
	 * e.printStackTrace(); } }
	 * 
	 * 
	 * public void regist() { //memberAdd=new MemberAdd(this); }
	 * 
	 * public void edit() { //memberEdit=new MemberEdit(this,member_list_id); }
	 * 
	 * public void searchMember(String keyWord) { for (int i = 0; i <
	 * table.getRowCount(); i++) { if (nameArray.size() < table.getRowCount()) {
	 * nameArray.add(table.getValueAt(i, 1)); } } for (int i = 0; i <
	 * nameArray.size(); i++) { String name = (String) nameArray.get(i); if
	 * (keyWord.equals(name)) { if (table.getValueAt(i, 1) == name) {
	 * table.setRowSelectionInterval(0, i); } } } } public void search() {
	 * Connection con = main.getCon(); PreparedStatement pstmt = null; ResultSet rs
	 * = null; String typed=t_search.getText();
	 * 
	 * String sql =
	 * "select * from member_list where member_list_phone like '%"+typed+"%'";
	 * //System.out.println(sql);
	 * 
	 * try { pstmt = con.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE,
	 * ResultSet.CONCUR_READ_ONLY); rs = pstmt.executeQuery(); rs.last(); int total
	 * = rs.getRow();
	 * 
	 * Object[][] data = new Object[total][model.columnTitle.length];
	 * rs.beforeFirst(); for (int i = 0; i < total; i++) { rs.next(); data[i][0] =
	 * rs.getInt("member_list_id"); data[i][1] = rs.getString("member_list_phone");
	 * data[i][2] = rs.getString("member_list_pw"); data[i][3] =
	 * rs.getString("member_list_date");
	 * 
	 * } model.data = data; table.updateUI(); } catch (SQLException e) {
	 * e.printStackTrace(); } finally { if (rs != null) { try { rs.close(); } catch
	 * (SQLException e) { e.printStackTrace(); } } if (pstmt != null) { try {
	 * pstmt.close(); } catch (SQLException e) { e.printStackTrace(); } } } }
	 */

}
