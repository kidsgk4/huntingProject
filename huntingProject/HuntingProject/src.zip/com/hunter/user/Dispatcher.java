package com.hunter.user;



import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Dispatcher {
	JSONParser jsonParser;
	ClientMain clientMain;
	Controller controller;
	UserMain main;
	public Dispatcher(UserMain main,ClientMain clientMain) {
		this.main = main;
		this.clientMain = clientMain;
		controller =new Controller(main);
	}
	
	public void dispatch(String msg) {
		jsonParser = new JSONParser();
		try {
			JSONObject obj = (JSONObject) jsonParser.parse(msg);
			String requestType = (String) obj.get("requestType");
			if(requestType.equals("entryinfo")) {
				int table_info_id = Integer.valueOf((String)obj.get("table_info_id"));
				String table_ip = (String) obj.get("table_ip");
				int entry_list_id = Integer.valueOf((String)obj.get("entry_list_id"));

				controller.setUserInfo(table_info_id,table_ip, entry_list_id);
				
			} else if(requestType.equals("checkidback")) {
				String idCheck = (String)obj.get("idCheck");
				
				controller.setCheckIdBack(idCheck);
			} else if(requestType.equals("checkloginback")) {
				String loginCheck = (String)obj.get("check");
				
				controller.setCheckLoginBack(loginCheck);
			} 

		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
	
}
