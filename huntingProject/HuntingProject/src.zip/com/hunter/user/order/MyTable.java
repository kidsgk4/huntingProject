package com.hunter.user.order;
import javax.swing.JFrame;

public class MyTable extends JFrame{

}
