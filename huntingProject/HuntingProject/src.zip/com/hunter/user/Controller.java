package com.hunter.user;

import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.swing.JOptionPane;

public class Controller {
	UserMain userMain;
	public Controller(UserMain userMain) {
		this.userMain = userMain;
		
		// TODO Auto-generated constructor stub
	}
	//���� ���� ����
	public void setUserInfo(int table_info_id,String table_ip,int entry_list_id) {
		userMain.user.setTableNum(table_info_id);
		userMain.user.setTableIp(table_ip);
		userMain.user.setEntryListId(entry_list_id);
		
	}
	
	public void setCheckIdBack(String check) {
		if(check.equals("true")) {
			JOptionPane.showMessageDialog(userMain,"��� ������ ID�Դϴ�!!" );
			userMain.joinMain.check=true;
		}else {
			JOptionPane.showMessageDialog(userMain,"�ߺ��� ID�Դϴ�!!" );
		}
	}
	public void setCheckLoginBack(String check) {
		if(check.equals("true")) {
			JOptionPane.showMessageDialog(userMain,"�α��� ����" );
		}else {
			JOptionPane.showMessageDialog(userMain,"�α��� ����" );
		}
	}
}
