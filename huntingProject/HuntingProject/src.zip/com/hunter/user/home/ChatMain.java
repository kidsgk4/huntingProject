package com.hunter.user.home;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import com.hunter.user.UserMain;



public class ChatMain extends JPanel {
   
   public ChatMain() {
      
      setBackground(Color.blue);
      setPreferredSize(new Dimension(500, 500));
   }

}