package com.hunter.user.game;

public enum ObjectType {
	Player1,Player2,Player3,Player4,Player5,Player6,Player7
}